<html>
    <head>
    <link href="generate_css.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="body"></div>
		<div class="grad"></div>
		<div class="header left">
			<div>Buat<span>Kode</span></div>
		</div>
    <div class="header left" >
     <br><br><br><a href="/bayarin">
                     <img style="width:175px" src="/bayarin/images/logo.png" style="float:left"/>
                    </a>
    </div>
		<br>
		<div class="generate_css">
        	<form method="post">
				<input type="text" placeholder="Kode Rahasia" name="kode"><br>
				<input type="text" placeholder="Nominal" name="nominal"><br>
				<input name = "submit" type="button" value="Generate">
                </form>
		</div>
    </body>
</html>
